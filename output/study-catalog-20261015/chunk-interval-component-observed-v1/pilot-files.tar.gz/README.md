# Real train interval pilot — component only

This isolated experiment compresses one real three-member SF group plus its matching native sentence (4 roots / 8 bilingual paragraphs). The whole real 29-row panel, other 26 rows, three member audits, occurrence IDs, marks, year controls and initial 27-row display remain. Real ancestor classes/attrs and original model CSS are retained. No production source, PG, packaging, current FRAME, service or frozen input fixture is changed.

## Files and APIs

- `a-original.html`: original markup + the frozen original card-chunks listener, plus the explicit one-group panel binding.
- `b-interval.html`: compact markup + `StudyChunkIntervals.install(document, profile, canonical, options)`. `refresh`, `stats`, `dispose`; optional `isCurrent` and `onInvalid`.
- `routes.json`: exact 20 sibling route files with SHA/bytes. `page-loader.js` is embedded; no external script or CSS endpoint is required. All initial fetches use the 18 fixed asset names. The CSS has only data URLs. Root may serve these exact files through its existing loopback snapshot server, e.g. `/a-original.html` and `/b-interval.html`; this pilot does not start a server.
- `source-bindings.json`, `canonical.json`, `common-helper-pins.json`: real source chain and unchanged common range helper evidence.
- `conversion-edits.json`, `render.cjs.expandHTML`: exact removed wrappers and complete component markup inverse without full-card regeneration.

## Source identity and semantic checks

Input is the frozen train `tests/fixtures/experimental-compiled-card-v1/train/final.html.gz`, decoded SHA `20e8e39afe32a44052dc3b03f6683c4bd43a91d2487ce23ce5fced685d8800de`. The original wrapper/payload/back/expanded/registry and original/prepared native module byte pins remain independently verified by the page loader. The original full native algorithms are not replayed in this component page; it is not full-FRAME, Anki import, or original native-gate acceptance.

`prepare-canonical.py` uses the shared `_example_chunk_ranges` function. The frozen original chunk IDs differ from the current reviewed-index ordering. Both exact English range and complete Chinese range set are used to certify the original-ID→reviewed-index bijection `[0,1,2,3,4,5,7,8,6]`; IDs are never guessed from sentence text. Runtime rederives the range table from full alignment and rejects a legal ID moved to a wrong position, even if a fresh transport SHA is supplied. Unknown/style/ARIA/tabindex/extra-class spans, target marks and nested chunk spans remain real DOM.

Candidate `outside-legacy.js` wraps only original listener registration. Events inside the four interval roots return before the original listener callback. The new runtime's handled counters, plus parity at all 82 source positions, prove those roots use the new owner; other panel rows keep legacy interaction. No old DOM compiled profile is read, and neither semantic errors nor absent hit-testing APIs fall back to it.

## Observed result

891→827 component elements, 82→18 target chunk spans (64 removable wrappers). Complete text, three audits, marks, member IDs/counts and exact original component markup inverse match; inverse/source SHA is `b1a63546d8adf5111a631c7a31d3c8d1b478e3fd4a5da65f1ca8d324b4d4f556`.

Source component is 183,746 bytes; compact HTML 179,138 bytes; new profile 24,001 bytes. HTML saves 4,608 bytes but HTML+profile adds 19,393 bytes. This is node/semantic feasibility, not a transport or performance win. Do not extrapolate this span fraction to the largest card or promise subsecond loading. A/B currently fetches about 6.8MB of identical source/proof assets.

19 small Node/JSDOM contracts pass. Meaningful REDs cover unchanged identity renderer, nearest-caret glyph edge, and stale/non-mouse pointerout. Fixed cases cover all real source span positions, English first ID, Chinese fine-before-whole, controlled Unicode/overlap/whole tooltip, hover/move/tap/Escape, controlled accessible keyboard/no-flip, legal-ID position tamper, filters, external mutation, cleanup/cancellation, no-old-profile and resource-tamper rejection. `evidence-logs.json` records reproducible gzip (mtime=0) raw test evidence and decoded SHAs.

## Explicit remaining acceptance

No browser was opened. JSDOM caret/range boxes are mocked. Real Safari must check wrapped line/glyph edge and blank-space hit testing, touch/pen/zoom, cursor/tooltip visual parity, native Find across text/inline boundaries and closed audits, keyboard controls, filter/reveal/dispose, and source-error UX. Full original-frame stable signature/fonts/child/cancellation gate and native runtime state are not claimed. The component page verifies resources and semantic bindings, mounts the entire component hidden, waits for fonts and three equal local component geometry snapshots, then reveals it.

## Small checks

From the repo root, with existing dependencies only:

```sh
NODE_PATH="$PWD/node_modules" /opt/homebrew/bin/node --test --test-concurrency=1 /tmp/study-interval-train-pilot-v2-20261017-pqmsamlc/renderer.test.cjs /tmp/study-interval-train-pilot-v2-20261017-pqmsamlc/runtime.test.cjs /tmp/study-interval-train-pilot-v2-20261017-pqmsamlc/page.test.cjs
```

`FROZEN.json` pins delivered inputs/code/assets/tests/reports. Do not rerun generators on this sealed directory; a follow-up should use a new directory/seal.

## v2 owner handoff correction

The original 9a3 seal is superseded. This sibling adds one exact, reversible capture statement inside the SHA-verified original card-chunks IIFE; its private `clear` implementation remains byte-for-byte unchanged. No keyboard/mouse event is fabricated or dispatched for cleanup. Before a validated interval activation paints, it invokes that explicit legacy private-clear bridge; after a real outside legacy activation, only the new owner's recorded paint is released. Original listener callbacks still never select or activate the four interval roots. Blank hover/invalid keys preserve tap state; blank click and cancellation retain original ownership rules. See `legacy-source-transform.json`, `supersedes.json` and `handoff.diff.gz`.
