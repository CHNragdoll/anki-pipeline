"""Controlled Unicode/overlap/whole fallback case, not a real source claim."""
from pathlib import Path
import hashlib,json
from anki_pipeline.packaging import _example_chunk_ranges,_chunk_segment,_annotate_sentence_chunks
here=Path(__file__).resolve().parent
english='A😀 BC & D';chinese='甲😀乙 & 丙'
alignment={'schema':'codex-sentence-alignment.v1','englishHash':hashlib.sha256(english.encode()).hexdigest(),'translationHash':hashlib.sha256(chinese.encode()).hexdigest(),'alignments':[{'en':[0,len(english)],'zh':[[0,len(chinese)]],'relation':'equivalent','note':'整句对应：controlled whole fallback'},{'en':[1,3],'zh':[[1,3]],'relation':'equivalent','note':'controlled finer'},{'en':[0,4],'zh':[[0,3]],'relation':'equivalent','note':'controlled overlap'}]}
en,zh,ok=_example_chunk_ranges({'text':english,'translation':chinese,'translation_source':'codex','translation_alignment':alignment});assert ok
canon={'schema':'study-chunk-interval-source.v1','controlledOnly':True,'english':english,'chinese':chinese,'alignment':alignment,'ranges':{'en':en,'zh':zh},'sentenceIds':[0]}
parts=[]
for side,text,ranges in [('en',english,en),('zh',chinese,zh)]:
 boundaries=sorted({0,len(text)}|{v for a,b,_ in ranges for v in(a,b)})
 markup=''.join(_chunk_segment(text[a:b],side,a,b,ranges) for a,b in zip(boundaries,boundaries[1:]))
 markup=_annotate_sentence_chunks(markup,alignment)
 parts.append('<p data-chunk-interval-paragraph="controlled:'+side+'">'+markup+'</p>')
source='<!DOCTYPE html><html><head></head><body><section class="sf-report"><div class="sf-panel" data-chunk-interval-panel="edge"><p class="sf-preview-count">显示 0 条原文</p></div></section><div class="example-card" data-chunk-interval-root="controlled">'+''.join(parts)+'</div></body></html>'
(here/'edge-canonical.json').write_text(json.dumps(canon,ensure_ascii=False,separators=(',',':')))
(here/'edge-source.html').write_text(source)
print('controlled shared-range fixture ready')
