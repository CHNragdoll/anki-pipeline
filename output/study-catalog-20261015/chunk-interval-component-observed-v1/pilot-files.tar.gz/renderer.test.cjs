'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {JSDOM}=require('jsdom'),dir=__dirname;
const render=require(process.env.INTERVAL_RENDERER||'./render.cjs');
const source=fs.readFileSync(path.join(dir,'source.html'),'utf8'),canonical=JSON.parse(fs.readFileSync(path.join(dir,'canonical.json'))),bindings=JSON.parse(fs.readFileSync(path.join(dir,'source-bindings.json')));
test('real train pilot reduces pure interaction span nodes before browser install without losing any text',()=>{
 const built=render.compile(source,canonical,bindings),before=new JSDOM(source),after=new JSDOM(built.html);
 try{assert.equal(after.window.document.body.textContent,before.window.document.body.textContent);assert(after.window.document.querySelectorAll('[data-chunk-interval-root] span.card-chunk').length<before.window.document.querySelectorAll('[data-chunk-interval-root] span.card-chunk').length,'unchanged source still builds every interaction span');}finally{before.window.close();after.window.close()}
});
