from pathlib import Path
import gzip,hashlib,json
from anki_pipeline.study_catalog_web import card_payload
root=Path(__file__).resolve().parent;cfg=json.loads((root/'config.json').read_text());repo=Path(cfg['repo'])
source=json.loads(Path('/tmp/study-canonical-train-producer-20261017-qs6mku8x/input.json').read_text());proof=json.loads((root/'source-bindings.json').read_text())['originalProof']
def put(name,raw,pin):
 if hashlib.sha256(raw).hexdigest()!=pin:raise ValueError('Source changed '+name)
 (root/name).write_bytes(raw)
wrapper=Path(source['wrapper_path']).read_bytes();put('original-wrapper.html',wrapper,proof['source_wrapper_sha256']);put('original-payload.json',card_payload(wrapper),proof['source_payload_sha256']);put('original-prepared.json',Path(source['artifact_path']).read_bytes(),proof['source_artifact_sha256']);put('original-native.js',Path(source['original_module_path']).read_bytes(),proof['native_original_sha256'])
module=source['artifact']['modules'][proof['native_original_sha256']]
put('prepared-native.js',(Path(source['artifact_path']).parent.parent/module['src']).read_bytes(),proof['native_prepared_sha256'])
put('full-canonical-source.html',gzip.decompress((Path(cfg['fixture'])/'train/final.html.gz').read_bytes()),'20e8e39afe32a44052dc3b03f6683c4bd43a91d2487ce23ce5fced685d8800de')
(root/'legacy-card-chunks.js').write_bytes((repo/'anki_pipeline/templates/card-chunks.js').read_bytes())
canonical=json.loads((root/'canonical.json').read_text());put('reviewed-index.json',Path(canonical['source_index']['path']).read_bytes(),canonical['source_index']['sha256'])
files=['reviewed-index.json','source-model.css','source.html','compact.html','profile.json','canonical.json','source-bindings.json','core.js','runtime.js','outside-legacy.js','legacy-card-chunks.js','pilot-panel.js','original-wrapper.html','original-payload.json','original-prepared.json','original-native.js','prepared-native.js','full-canonical-source.html']
assets={name:{'sha256':hashlib.sha256((root/name).read_bytes()).hexdigest(),'bytes':(root/name).stat().st_size} for name in files};build=json.loads((root/'build-report.json').read_text())
loader=(root/'page-loader.js').read_text()
for mode,name in [('source','a-original.html'),('interval','b-interval.html')]:
 config=json.dumps({'mode':mode,'assets':assets,'build':build},ensure_ascii=False,separators=(',',':')).replace('<','\\u003c')
 title='Train 单 panel / '+mode
 page='<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+title+'</title><style>#pilot[hidden]{display:block!important;visibility:hidden}#pilot-toolbar{position:sticky;top:0;z-index:9999;background:white;color:#222;border:1px solid #ddd;padding:.6rem;font:14px/1.5 sans-serif}#pilot-result{white-space:pre-wrap;overflow-wrap:anywhere}</style></head><body class="card"><div id="pilot-toolbar"><strong>'+title+'</strong> <a href="a-original.html">原版</a> · <a href="b-interval.html">区间版</a> <button id="pilot-check">读取当前证据</button><p id="pilot-status">校验中…</p></div><main id="pilot" hidden></main><pre id="pilot-result" hidden></pre><script type="application/json" id="pilot-config">'+config+'</script><script>'+loader+'</script></body></html>'
 (root/name).write_text(page)
(root/'browser-assets.json').write_text(json.dumps(assets,indent=2)+'\n')
print(json.dumps({'pages':['a-original.html','b-interval.html'],'asset_bytes':sum(v['bytes'] for v in assets.values()),'source_proof':'original wrapper/payload/side/expanded/registry/native and prepared-module byte SHA, plus frozen canonical full HTML, all checked; no original native algorithm/full FRAME gate replay claimed'}))
