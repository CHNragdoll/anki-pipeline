(function(g){'use strict';
g.installIntervalOutsideLegacy=function(doc,source,stats,options={}){
 const win=doc.defaultView,current=options.isCurrent||(()=>true),captureKey='__studyIntervalLegacyClearCapture';
 const before='  function activate(selected, mode) {',after='  window.'+captureKey+'(clear);\n'+before;
 if(typeof source!=='string'||source.split(before).length!==2||Object.prototype.hasOwnProperty.call(win,captureKey))throw Error('Legacy clear capture exact boundary');
 let clear=null,captures=0,keydownCount=0;
 Object.defineProperty(win,captureKey,{configurable:true,value:fn=>{if(typeof fn!=='function'||++captures!==1)throw Error('Legacy clear capture count');clear=fn}});
 const had=Object.prototype.hasOwnProperty.call(doc,'addEventListener'),prior=doc.addEventListener;
 function release(){if(!current()||!clear)return false;if(!win.__ankiCardChunkState)return true;clear();stats.releasedOutside=(stats.releasedOutside||0)+1;return true}
 doc.addEventListener=function(type,callback,listenerOptions){if(type==='keydown'&&++keydownCount!==1)throw Error('Legacy keydown registration count');return prior.call(doc,type,function(event){const target=event.target?.nodeType===1?event.target:event.target?.parentElement;
  if(target?.closest('[data-chunk-interval-root]')){stats.skippedTarget++;if(type==='click'||(type==='keydown'&&event.key==='Escape')||(['pointerover','mouseover'].includes(type)&&(!event.pointerType||event.pointerType==='mouse')&&win.__ankiCardChunkState?.mode==='hover'))release();return}
  stats.executedOutside++;const result=callback.call(this,event);if(['click','pointerover','mouseover'].includes(type)&&win.__ankiCardChunkState?.root&&!win.__ankiCardChunkState.root.closest('[data-chunk-interval-root]'))options.onActive?.();return result;
 },listenerOptions)};
 try{win.eval(source.replace(before,after));if(captures!==1||keydownCount!==1)throw Error('Legacy capture/registration incomplete')}finally{if(had)doc.addEventListener=prior;else delete doc.addEventListener;delete win[captureKey]}
 return Object.freeze({release});
};})(window);
