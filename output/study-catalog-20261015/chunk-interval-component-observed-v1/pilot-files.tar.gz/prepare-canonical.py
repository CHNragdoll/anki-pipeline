"""Bind a frozen pilot's original ID order to exact reviewed alignment ranges."""
from pathlib import Path
import hashlib,json
from copy import deepcopy
from anki_pipeline.packaging import _example_chunk_ranges
HERE=Path(__file__).resolve().parent
index=Path('/Users/apple/Documents/PyCharm/Anki/exam-library/data/staging/codex-translations-v1/index/2026-02.json')
member_file=Path('/tmp/study-canonical-train-producer-20261017-qs6mku8x/full-authored-capture/members-before.json')
raw=index.read_bytes();row=next(r for r in json.loads(raw)['sentences'] if r['id']=='kaoyan:2026-02:p:b-7-4:1')
prior=member_file.read_bytes();member=next(r for r in json.loads(prior) if r['key']=='source-00191')
assert member['english']==row['english'] and member['chinese']==row['translationZh']
def merged(parts):
 result=[]
 for a,b in sorted(set(map(tuple,parts))):
  if result and a<=result[-1][1]:result[-1][1]=max(result[-1][1],b)
  else:result.append([a,b])
 return result
def cp(text,offset):
 boundaries={len(text[:i].encode('utf-16-le'))//2:i for i in range(len(text)+1)}
 return boundaries[offset]
def ranges(side):
 result={};text=member['english' if side=='en' else 'chinese']
 for run in member[side+'_runs']:
  for ancestor in run['ancestors']:
   attrs=dict(ancestor['attrs'])
   if attrs.get('data-chunk-side')!=side:continue
   for identity in attrs.get('data-chunk-ids','').split():
    result.setdefault(int(identity),[]).append([cp(text,run['start_utf16']),cp(text,run['end_utf16'])])
 return {identity:merged(parts) for identity,parts in result.items()}
en,zh=ranges('en'),ranges('zh');assert sorted(en)==list(range(len(row['alignments'])))==sorted(zh)
order=[]
for identity in sorted(en):
 assert len(en[identity])==1
 matches=[i for i,a in enumerate(row['alignments']) if a['en']==en[identity][0] and merged(a['zh'])==zh[identity] and a['relation']=='equivalent']
 assert len(matches)==1
 order.append(matches[0])
assert len(set(order))==len(order)
alignment={'schema':'codex-sentence-alignment.v1','englishHash':row['englishHash'],'translationHash':row['translationHash'],'alignments':[deepcopy(row['alignments'][i]) for i in order]}
english,chinese,ok=_example_chunk_ranges({'text':row['english'],'translation':row['translationZh'],'translation_source':'codex','translation_alignment':alignment});assert ok
seed={'schema':'study-chunk-interval-source.v1','source_index':{'path':str(index),'sha256':hashlib.sha256(raw).hexdigest()},'frozen_members':{'path':str(member_file),'sha256':hashlib.sha256(prior).hexdigest(),'key':member['key']},'originalIdToReviewedIndex':order,'identityBridge':'Exact English range and complete merged Chinese ranges; bijective; never text-only matching. Original frozen IDs are preserved.','sentence_id':row['id'],'english':row['english'],'chinese':row['translationZh'],'alignment':alignment,'ranges':{'en':english,'zh':chinese},'sentenceIds':[i for i,a in enumerate(alignment['alignments']) if a.get('note','').startswith('整句对应：')]}
(HERE/'canonical.json').write_text(json.dumps(seed,ensure_ascii=False,sort_keys=True,separators=(',',':')))
print(json.dumps({'originalIdToReviewedIndex':order,'ranges':len(english),'frozenIdsPreserved':True}))
