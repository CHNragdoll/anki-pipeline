'use strict';
const fs=require('node:fs'),path=require('node:path'),z=require('node:zlib'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const {JSDOM}=require('jsdom');
const dir=__dirname,config=JSON.parse(fs.readFileSync(path.join(dir,'config.json'))),fixture=config.fixture;
const sha=s=>crypto.createHash('sha256').update(s).digest('hex');
const raw=z.gunzipSync(fs.readFileSync(path.join(fixture,'train/final.html.gz')));
assert.equal(sha(raw),'20e8e39afe32a44052dc3b03f6683c4bd43a91d2487ce23ce5fced685d8800de');
const proof=JSON.parse(fs.readFileSync(path.join(fixture,'train/group-merge-proof.json'))),canon=JSON.parse(fs.readFileSync(path.join(dir,'canonical.json')));
const original=new JSDOM(raw.toString()),d=original.window.document;
try{
 const members=proof.target_occurrence_ids.map(id=>d.querySelector('[data-sf-occurrence-id="'+id+'"]'));
 assert(members.every(Boolean));const panel=members[0].parentElement;assert(members.every(n=>n.parentElement===panel));
 const sense=panel.closest('.sf-sense');assert(sense);const natives=[...d.querySelectorAll('.examples-section li.example-card')].filter(n=>n.querySelector('.example-text')?.textContent===canon.english);assert.equal(natives.length,1);
 const chosen=[sense,natives[0]];function selectedTree(node){if(chosen.includes(node))return node.cloneNode(true);if(!chosen.some(n=>node.contains?.(n)))return null;const copy=node.cloneNode(false);for(const child of node.childNodes){const part=selectedTree(child);if(part)copy.append(part);else if(child.nodeType===3&&!child.data.trim())copy.append(child.cloneNode());}return copy;}const selectedBody=selectedTree(d.body),fragment=selectedBody.innerHTML;
 const styles=fs.readFileSync(path.join(dir,'source-model.css'),'utf8')+'\n'+[...d.head.querySelectorAll('style')].map(n=>n.textContent).join('\n');
 const out=new JSDOM('<!doctype html><html><head><meta charset="utf-8"><style>'+styles+'</style></head><body class="card">'+fragment+'</body></html>');
 try{
  const doc=out.window.document,roots=[];
  for(const id of proof.target_occurrence_ids){const n=doc.querySelector('[data-sf-occurrence-id="'+id+'"]');n.setAttribute('data-chunk-interval-root','sf:'+id);roots.push({key:'sf:'+id,kind:'sf',occurrenceId:id});}
  const native=doc.querySelector('.examples-section li.example-card'),key='native:'+sha(native.outerHTML);native.setAttribute('data-chunk-interval-root',key);roots.push({key,kind:'native',occurrenceId:null});
  const ownPanel=doc.querySelector('.sf-panel');ownPanel.setAttribute('data-chunk-interval-panel','panel-0');
  for(const r of roots){const root=doc.querySelector('[data-chunk-interval-root="'+r.key+'"]');for(const side of ['en','zh']){const p=root.querySelector(r.kind==='sf'?':scope>.sf-sentence-pair .sf-'+side:(side==='en'?'.example-text':'.example-translation'));assert(p);p.setAttribute('data-chunk-interval-paragraph',r.key+':'+side);}}
  const source=out.serialize();fs.writeFileSync(path.join(dir,'source.html'),source);
  const metadata={schema:'study-chunk-interval-pilot-source.v1',sourceModelCSSSha256:'f795b3b62aed93ded59ba8b4027568931dd87e41c64d099c24e1ee997cc8e589',sourceFullHTMLSha256:sha(raw),componentUnanchoredSha256:sha(fragment),sourceHTMLSha256:sha(source),canonicalSha256:sha(fs.readFileSync(path.join(dir,'canonical.json'))),originalProof:proof,roots,panel:{key:'panel-0',members:[...ownPanel.querySelectorAll(':scope>.sf-example')].map(n=>({id:n.dataset.sfOccurrenceId,year:n.dataset.sfYear,hidden:n.hidden})),groups:[proof.target_occurrence_ids],status:ownPanel.querySelector(':scope>.sf-preview-count').textContent},scope:'One real complete 29-row sense panel, only three merged members plus one corresponding native root are compressed. No old DOM profile is loaded.'};
  fs.writeFileSync(path.join(dir,'source-bindings.json'),JSON.stringify(metadata,null,2));console.log(JSON.stringify({sourceBytes:Buffer.byteLength(source),members:metadata.panel.members.length,roots:roots.length,groupMembers:proof.target_occurrence_ids.length}));
 }finally{out.window.close()}
}finally{original.window.close()}
