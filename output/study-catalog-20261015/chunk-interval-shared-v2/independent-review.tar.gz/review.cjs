const fs=require('node:fs'),assert=require('node:assert/strict'),{test}=require('node:test'),crypto=require('node:crypto');
const repo='/Users/apple/Documents/PyCharm/Anki/anki_rebuild';
const helper=repo+'/tests/study_chunk_intervals.test.cjs';
const raw=fs.readFileSync(helper,'utf8');const prefix=raw.slice(0,raw.indexOf("\ntest('common interval"));
const {fixture,samples,flattened,ROOT,PAR}=new Function('require','__dirname',prefix+'\nreturn {fixture,samples,flattened,ROOT,PAR};')(require('node:module').createRequire(helper),repo+'/tests');
const results=[];
process.on('exit',()=>fs.writeFileSync(__dirname+'/observed.json',JSON.stringify(results,null,2)));
test('bound occurrence identity cannot drift and then paint without invalidation',()=>{
 const f=fixture('train');try{const p=flattened(f.profile)[0],root=f.parFor(p.key).closest('['+ROOT+']'),physicalOwner=root.closest('[data-sf-occurrence-id]');assert(physicalOwner,'expected real SF owner');const before=physicalOwner.dataset.sfOccurrenceId;
 physicalOwner.dataset.sfOccurrenceId='f'.repeat(64);f.dispatch(p,0);
 results.push({case:'bound-occurrence-drift',before,after:physicalOwner.dataset.sfOccurrenceId,ownerTag:physicalOwner.localName,ownerIsRoot:physicalOwner===root,active:f.active().length,stats:f.handle.stats()});
 assert.equal(f.active().length,0,'changed physical owner must be rejected before paint');
 assert(f.handle.stats().invalid,'changed owner must invalidate current handle');
 }finally{f.close();}
});
test('one document cannot acquire two simultaneous interval owners',()=>{
 const f=fixture();let other=null,error=null;try{const p=samples.tiny.profile;
 try{other=f.w.StudyChunkIntervals.install(f.d,p,{binding:{source_sha256:p.source_sha256,compact_sha256:p.compact_sha256,profile_sha256:samples.tiny.profile_sha256,css_sha256:p.css_sha256},isCurrent:()=>true,clearLegacy(){}});}catch(e){error=e;}
 f.dispatch(flattened(f.profile)[0],0);results.push({case:'duplicate-install',rejected:!!error,first:f.handle.stats(),second:other?.stats()||null});
 assert(error,'a second current handle must be rejected before adding listeners');
 }finally{other?.dispose();f.close();}
});
test('Shift Enter follows the real original Projection keyboard contract',()=>{
 const file='/tmp/study-interval-train-pilot-v2-20261017-pqmsamlc/original-native.js',source=fs.readFileSync(file,'utf8');
 assert.equal(crypto.createHash('sha256').update(source).digest('hex'),'be39224f5f2d47eee8cad80060aeb364e72448b5cd1c11a7f7c8fd8d999e1b93');
 const at=source.indexOf('      if (!wrappers.has(el) || el.closest(');assert(at>0);
 const start=source.lastIndexOf('    function keyboard(event) {',at),end=source.indexOf('\n    var observer',at);assert(start>0&&end>start);
 const original=source.slice(start,end);fs.writeFileSync(__dirname+'/original-projection-keyboard.js',original);
 const old=fixture('rich',{legacy:true,html:samples.rich.source}),next=fixture('rich');try{
 const oldNode=old.d.getElementById('original'),newNode=next.d.getElementById('original');
 const keyboard=new Function('doc','wrappers','disposed',original+'\nreturn keyboard;')(old.d,new Set([oldNode]),false);
 old.d.addEventListener('keydown',keyboard,true);
 const a=old.fire('keydown',oldNode,{key:'Enter',shiftKey:true}),b=next.fire('keydown',newNode,{key:'Enter',shiftKey:true});
 results.push({case:'shift-enter',oldPrevented:a.defaultPrevented,newPrevented:b.defaultPrevented,oldActive:old.active().length,newActive:next.active().length});
 assert.equal(b.defaultPrevented,a.defaultPrevented,'source keyboard accepts Shift+Enter');assert.deepEqual(next.active(),old.active());
 }finally{next.close();old.close();}
});
