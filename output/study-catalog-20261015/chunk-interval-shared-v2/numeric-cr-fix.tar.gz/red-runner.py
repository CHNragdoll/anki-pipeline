import sys,types,unittest,anki_pipeline
from pathlib import Path
name='anki_pipeline.study_chunk_intervals'
m=types.ModuleType(name);m.__file__=sys.argv[1];sys.modules[name]=m
setattr(anki_pipeline,'study_chunk_intervals',m)
exec(compile(Path(sys.argv[1]).read_bytes(),sys.argv[1],'exec'),m.__dict__)
from tests.test_study_chunk_intervals import ChunkIntervalsTests
s=unittest.TestSuite([ChunkIntervalsTests('test_numeric_cr_is_preserved_but_literal_crlf_is_normalized_before_dom_binding')])
r=unittest.TextTestRunner(verbosity=2).run(s)
raise SystemExit(0 if r.wasSuccessful() else 1)
