# Chunk intervals / compiled FRAME compatibility review

This is the completed read-only analysis packaged for later integration. No source, old archive, seal, database, service, formal entry or package was edited. No test, producer, browser, giant DOM or semantic scan was rerun while packaging.

## Findings established by the completed review

1. The current interval compiler removable-attribute whitelist excludes `data-study-compiled-key`. A span that is directly named by an existing compiled node binding is therefore retained, not unwrapped. In the inspected small frozen profiles, abolish has eight and train has twenty bound chunk spans; these are `projection-keyboard-wrapper` nodes carrying keyboard/accessibility/reviewed attributes and must remain. This does not assert an independently rescanned maximum-card count.
2. The old compiled profile still cannot be reused verbatim. Unwrapping an unbound span can shift sibling `childNodes` paths after adjacent text coalesces; newly added root/paragraph attributes also conflict with exact `requiredAttrs`/extra-attribute checks. Both `nodeBindings.relativePath` and `readerLinks.relativePath` may need representation-only remapping.
3. The actual e56-family history binder rejects a dynamic plain Text wrap even when root text is unchanged. The recorded tiny source/result is preserved here. The existing record checker, position/reader validation and history graph all need an explicit owned transformation protocol; ignoring observer records alone is insufficient.
4. The original authored chunk delegate has a private `clear`, global active-root state and capture click processing. A second renderer listener without an explicit ownership handoff can double-handle painted `.card-chunk` nodes.

## Minimum controlled seam suggested

- Produce a local pre/post paragraph-path ledger during the same byte-stream compaction pass, tied to exact original source/root/paragraph identity. Preserve all keyed, reader, Bank, projection, target/default-emphasis and interactive nodes. Remap only affected paths and the expressly introduced anchor attributes. Keep panels/groups/bankRecords/projectionWrappers/source identities unchanged. Exact text must remain unchanged, without trimming or semantic re-alignment.
- Compute final childNodes semantics, including adjacent Text merging, entities, CRLF and comments. Do not count parser callback events as DOM children. Reject or preserve unsupported implicit-close/table/template/namespace contexts. The inspected lightweight parse5 reference is useful for small differential contracts, not permission to rerun the failed giant JSDOM route.
- Bind compact HTML, interval plan, rewritten compiled profile and CSS capability to one external descriptor and the original source SHA/inverse. A key or DOM flag alone grants no authority. Do not rewrite old archives.
- A private owned-paint capability should originate from the authenticated support.load result and be bound to actual doc, packet/view token, root/paragraph object and frozen plan. Drain existing pending MO records through the original checker before the synchronous owned writes. Consume only exact own target/type/added/removed/Text-split records, then revalidate text, retained nodes and semantic boundaries. Do not disconnect, discard a whole batch, or bless a current DOM scan as a new baseline.
- Maintain a deterministic local path overlay/logical child view for those owned transient nodes. Removal/disposal must undo only owned postimages, preserve/reject foreign mutations, and release the owner/document references. History/AF graph writes need their own exact slot/part authorization; a historical class is not an exemption.
- Add a pinned private legacy-clear/owned-release handoff at the original authored delegate boundary. Preserve the original routes for retained ARIA/fine/default-emphasis nodes, readers, links, summary and audio. Keep all original source/module checks and native/font/child/stable-geometry FRAME gates.

## Authored-markup fidelity tier

A separate explicitly labelled tier can replay original span locations, IDs and attributes without claiming a newly verified canonical alignment. Exact source SHA plus reversibility proves original representation; it does not establish independent canonical semantics. Treat it as a representation attachment to an already legitimate semantic compiled profile, or limit historical roots to explicit evidence that every existing semantic consumer excludes them. The existing history protocol requires empty Fine/Bank/Group/residual consumer tables and excluded projection pairs.

Never make `StudyCompiledProfileBridge.get()` return a semantic compiled profile solely because a fidelity certificate exists. The original compiled Slim branch selects the compiled binder and skips the original Fine/Projection/Bank/Group install-and-verify route. Such a promotion would change authority rather than merely compress markup. Unknown historical roots remain original until their exact source/consumer/tree scope is proved.

## Source pointers at review

- interval compiler: `_ALLOWED`, removable span predicate and root/paragraph markers
- history runtime.js: node binding setup 18-29; history graph 49-81; mutation handling 85-102; exact node/path/attributes 104-110
- compiled history Slim: compiled-vs-original branch 311-342
- authored chunk delegate: private clear/activate 37-53; capture click 88-98
- AST reference: child-node paths 36; DOM index 37-42; profile paths/attributes/readers 45-63

Input snapshots and SHA values are in `input-pins.json`. These SHA values were captured while packaging, after the review. In particular the new compiler was explicitly in progress; its captured SHA is not represented as a retroactive execution-time freeze. The tiny run is a previously observed 0.698-second functional result, not repeated here. No Safari, maximum-card, end-to-end FRAME integration or performance acceptance is claimed.
